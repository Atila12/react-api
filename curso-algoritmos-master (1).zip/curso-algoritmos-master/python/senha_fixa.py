senha: int

senha = int(input("Digite a senha: "))

while senha != 2002:
	senha = int(input("Senha Invalida! Tente novamente: "))

print("Acesso permitido!")